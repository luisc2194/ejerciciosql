
create database ejercicioluis;


create table clientes (
	id int auto_increment primary key,
	Nombre varchar (40) not NULL,
	Apellido varchar (40) not NULL,
	Edad tinyint (2) not NULL,
	fecha timestamp not NULL,
	Provincia varchar (50) not NULL
	
);


insert into clientes (Nombre, Apellido, Edad, Provincia) values 
	('Luis', 'Castro', '29', 'Buenos Aires'),
	('Pedro', 'Perez', '35', 'Jujuy'),
	('veronica', 'Garcia', '29', 'La Rioja'),
	('Laura', 'Ferrari', '26', 'Corrientes'),
	('Maria', 'Gonzalez', '33', 'Tucuman');

show fields from clientes;







